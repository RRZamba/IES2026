<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>

	<!-- Bootstrap 5 CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

	<div class="container mt-4">
		<div class="card p-4 shadow">
			<h3 class="text-center mb-4">Login</h3>
				<form action="doLogin.php" method="POST">
					<div class="mb-3">
						<label class="form-label">
							login
						</label>
						<input class="form-control" type="text" name="login" required>
					</div>

					<div class="mb-3">
						<label class="form-label">
							Senha
						</label>
						<input class="form-control" type="password" name="senha" required>
					</div>

					<div class="d-grid mb-3">
						<button type="submit"class="btn btn-primary">
							Entrar!!!
						</button>
					</div>

					<div class="text-center mb-2">
						<a href="#">Esqueci a senha</a>
					</div>

					<div class="text-center mb-2">
						<a href="#">Não possuo registro</a>
					</div>

				</form>
		</div>
	</div>






<!-- Bootstrap 5 JS (opcional) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>